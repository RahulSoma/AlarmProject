﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Diagnostics;

namespace DailyAlarm
{
    public partial class DailyAlarm : Form
    {

        #region Global Variables

        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["newConnectionString"].ConnectionString);

        #endregion

        #region Events

        public DailyAlarm()
        {
            InitializeComponent();
        }

        private void btnReadHTMLFile_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = string.Empty;
                    fileName = dialog.FileName;
                    string text = File.ReadAllText(fileName);
                    WebClient client = new WebClient();
                    string html = client.DownloadString(fileName);

                    dt = HTMLParser.ParseTable(text);

                    if (BulkInsert(dt))
                    {
                        MessageBox.Show("Record Read Successfull.", "Data Read", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnProcessXML.Enabled = true;
                        btnReadHTMLFile.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnProcessXML_Click(object sender, EventArgs e)
        {
            try
            {
                if (processDatatable())
                {
                    if (exportToExcel())
                    {
                        MessageBox.Show("Excel Generated Successfully.", "Export Excel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnProcessXML.Enabled = false;
                        btnReadHTMLFile.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region User Defined

        private Boolean BulkInsert(DataTable dtBulk)
        {
            try
            {
                using (var bulkcopy = new SqlBulkCopy(con))
                {
                    con.Open();
                    foreach (DataColumn col in dtBulk.Columns)
                    {
                        bulkcopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    }
                    bulkcopy.DestinationTableName = "DailyAlarm";
                    bulkcopy.WriteToServer(dtBulk);
                    con.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }

        private Boolean processDatatable()
        {
            try
            {
                con.Open();
                String str = "select column0 as SrNo, column1 as Severity, column2 as EventTime, column3 as AlarmName, column4 as AlarmClass, column5 as AlarmState, column6 as Message, column7 as ConditionQuality from DailyAlarm where column1 <> '1' and ((column3 not like '%_ALM_LL') and (column3 not like '%_ALM_HH')) and column4 like '%Process%'";
                SqlDataAdapter adp = new SqlDataAdapter(str, con);
                System.Data.DataTable dt = new System.Data.DataTable();
                adp.Fill(dt);
                con.Close();

                using (var bulkcopy = new SqlBulkCopy(con))
                {
                    con.Open();
                    foreach (DataColumn col in dt.Columns)
                    {
                        bulkcopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    }
                    bulkcopy.DestinationTableName = "ProcessedAlarm";
                    bulkcopy.WriteToServer(dt);
                    con.Close();

                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }

        private Boolean exportToExcel()
        {
            try
            {
                con.Open();
                String str = "select AlarmName, count(*) as count from ProcessedAlarm group by AlarmName";
                SqlDataAdapter adp = new SqlDataAdapter(str, con);
                DataTable dtExcel = new DataTable();
                adp.Fill(dtExcel);
                con.Close();
                exportDataToExcel(dtExcel);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return false;
        }

        private void exportDataToExcel(DataTable dtExport)
        {
            /*Set up work book, work sheets, and excel application*/
            Microsoft.Office.Interop.Excel.Application oexcel = new Microsoft.Office.Interop.Excel.Application();
            try
            {
                string path = AppDomain.CurrentDomain.BaseDirectory;
                object misValue = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Excel.Workbook obook = oexcel.Workbooks.Add(misValue);
                Microsoft.Office.Interop.Excel.Worksheet osheet = new Microsoft.Office.Interop.Excel.Worksheet();

                osheet = (Microsoft.Office.Interop.Excel.Worksheet)obook.Sheets["Sheet1"];
                int colIndex = 0;
                int rowIndex = 1;

                foreach (DataColumn dc in dtExport.Columns)
                {
                    colIndex++;
                    osheet.Cells[1, colIndex] = dc.ColumnName;
                }
                foreach (DataRow dr in dtExport.Rows)
                {
                    rowIndex++;
                    colIndex = 0;

                    foreach (DataColumn dc in dtExport.Columns)
                    {
                        colIndex++;
                        osheet.Cells[rowIndex, colIndex] = dr[dc.ColumnName];
                    }
                }

                //osheet.Columns.AutoFit();
                osheet.Columns["A:B"].AutoFit();
                //string filepath = @"C:\Data\Rahul Data\Data\Desktop\ExcelOutput\DailyAlarm";
                string appPath = string.Empty;
                string directoryPath = string.Empty;
                string filePath = string.Empty;
                appPath = Application.StartupPath;
                directoryPath = appPath + "/ExcelOutput";
                filePath = appPath + "/ExcelOutput/DailyAlarm";

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }

                //Release and terminate excel

                obook.SaveAs(filePath);
                obook.Close();
                oexcel.Quit();
                releaseObject(osheet);
                releaseObject(obook);
                releaseObject(oexcel);
                GC.Collect();
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(oexcel);

                Process[] excelProcesses = Process.GetProcessesByName("excel");
                foreach (Process p in excelProcesses)
                {
                    if (string.IsNullOrEmpty(p.MainWindowTitle)) // use MainWindowTitle to distinguish this excel process with other excel processes 
                    {
                        p.Kill();
                    }
                }
            }
            catch (Exception ex)
            {
                oexcel.Quit();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                //MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                GC.Collect();
            }
        }

        #endregion

    }
}
